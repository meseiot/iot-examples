﻿namespace IoT_Gonder_Al
{
    internal class MyResponse
    {
    }
}