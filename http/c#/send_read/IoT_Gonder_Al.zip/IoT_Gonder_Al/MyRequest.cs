﻿namespace IoT_Gonder_Al
{
    internal class MyRequest
    {
        public string Data { get; set; }
    }
}